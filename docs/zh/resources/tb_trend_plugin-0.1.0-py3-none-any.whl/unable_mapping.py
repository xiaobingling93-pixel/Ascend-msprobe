import sqlite3
import shutil
from pathlib import Path

def transform_database(source_db_path, target_db_path):
    """
    转换数据库结构：
    - 扩展trend_data表，将id映射为名称
    - 删除monitoring_metrics和monitoring_targets表
    - 其他表保持不变
    """
    
    # 确保目标目录存在
    Path(target_db_path).parent.mkdir(parents=True, exist_ok=True)
    
    # 复制原始数据库到新文件
    shutil.copy2(source_db_path, target_db_path)
    
    with sqlite3.connect(target_db_path) as conn:
        cursor = conn.cursor()
        
        # 检查必要的表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        required_tables = ['trend_data', 'monitoring_metrics', 'monitoring_targets']
        for table in required_tables:
            if table not in tables:
                raise ValueError(f"必需的表 {table} 在数据库中不存在")
        
        # 创建新的trend_data表结构
        cursor.execute("""
        CREATE TABLE trend_data_new (
            rank INTEGER,
            step INTEGER,
            target_name TEXT,
            vpp_stage TEXT,
            micro_step TEXT,
            metric_name TEXT,
            norm REAL,
            max REAL,
            min REAL,
            mean REAL
        )
        """)
        
        # 从monitoring_targets表获取target信息
        cursor.execute("""
        SELECT target_id, target_name, vpp_stage, micro_step 
        FROM monitoring_targets
        """)
        target_mapping = {}
        for row in cursor.fetchall():
            target_id, target_name, vpp_stage, micro_step = row
            target_mapping[target_id] = {
                'target_name': target_name,
                'vpp_stage': vpp_stage,
                'micro_step': micro_step
            }
        
        # 从monitoring_metrics表获取metric信息
        cursor.execute("""
        SELECT metric_id, metric_name FROM monitoring_metrics
        """)
        metric_mapping = {}
        for row in cursor.fetchall():
            metric_id, metric_name = row
            metric_mapping[metric_id] = metric_name
        
        # 转换并插入数据到新表
        cursor.execute("SELECT rank, step, target_id, metric_id, norm, max, min, mean FROM trend_data")
        
        for row in cursor.fetchall():
            rank, step, target_id, metric_id, norm, max_val, min_val, mean_val = row
            
            # 获取映射信息
            target_info = target_mapping.get(target_id, {
                'target_name': f'Unknown_{target_id}',
                'vpp_stage': 'Unknown',
                'micro_step': 'Unknown'
            })
            
            metric_name = metric_mapping.get(metric_id, f'Unknown_{metric_id}')
            
            # 插入新数据
            cursor.execute("""
            INSERT INTO trend_data_new 
            (rank, step, target_name, vpp_stage, micro_step, metric_name, norm, max, min, mean)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (rank, step, target_info['target_name'], target_info['vpp_stage'], 
                  target_info['micro_step'], metric_name, norm, max_val, min_val, mean_val))
        
        # 删除旧的trend_data表
        cursor.execute("DROP TABLE trend_data")
        
        # 重命名新表为trend_data
        cursor.execute("ALTER TABLE trend_data_new RENAME TO trend_data")
        
        # 删除不再需要的表
        cursor.execute("DROP TABLE monitoring_metrics")
        cursor.execute("DROP TABLE monitoring_targets")
        
        # 提交更改
        conn.commit()
        
        print(f"数据库转换完成！")
        print(f"源文件: {source_db_path}")
        print(f"目标文件: {target_db_path}")
        
        # 验证转换结果
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        remaining_tables = [row[0] for row in cursor.fetchall()]
        print(f"转换后的表: {remaining_tables}")
        
        # 显示新的trend_data表结构
        cursor.execute("PRAGMA table_info(trend_data)")
        columns = cursor.fetchall()
        print("新的trend_data表结构:")
        for col in columns:
            print(f"  {col[1]} ({col[2]})")

def main():
    # 配置路径
    source_db_path = r"D:/codes/MoniVis\db\dump_single/monitor_metrics.db"  # 原始数据库文件
    target_db_path = r"D:/codes/MoniVis\db\dump_single/monitor_metrics_no_map.db"  # 转换后的数据库文件
    
    try:
        transform_database(source_db_path, target_db_path)
        
        # 可选：验证数据转换是否正确
        with sqlite3.connect(target_db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM trend_data LIMIT 5")
            sample_data = cursor.fetchall()
            
            print("\n转换后的数据样例:")
            cursor.execute("PRAGMA table_info(trend_data)")
            columns = [col[1] for col in cursor.fetchall()]
            print("列名:", columns)
            
            for i, row in enumerate(sample_data):
                print(f"行 {i+1}: {row}")
                
    except Exception as e:
        print(f"转换过程中发生错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()