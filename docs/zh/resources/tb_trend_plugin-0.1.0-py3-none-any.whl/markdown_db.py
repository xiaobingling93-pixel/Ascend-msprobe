import sqlite3
from datetime import datetime
from pprint import pprint
from textwrap import dedent


def export_full_schema_to_markdown(db_path, output_file):
    """
    导出完整数据库结构到Markdown文件，包含：
    - 表基本信息
    - 列详细信息（类型、主键、非空等）
    - 索引定义
    - 外键关系
    - 数据样例
    """
    with sqlite3.connect(db_path) as conn, \
            open(output_file, 'w', encoding='utf-8') as md_file:

        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        # 写入文档头部
        md_file.write(dedent("""\
        # 数据库结构文档

        > 自动生成时间：{date}
        > 数据库文件：`{db_path}`

        """).format(
            date=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            db_path=db_path
        ))

        # 获取所有表（排除系统表）
        cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='table' 
        AND name NOT LIKE 'sqlite_%'
        ORDER BY name
        """)
        tables = [row['name'] for row in cursor.fetchall()]

        for table in tables:
            # --- 表基本信息 ---
            cursor.execute(
                f"SELECT sql FROM sqlite_master WHERE name='{table}'")
            create_sql = cursor.fetchone()[0]

            md_file.write(
                f"\n\n## 表 `{table}`\n\n"
                f"```sql\n"
                f"{create_sql}\n"
                f"```\n\n"
                f"### 表结构\n"
            )
            # --- 列详细信息 ---
            cursor.execute(f"PRAGMA table_info({table})")
            columns = [dict(row) for row in cursor.fetchall()]

            md_file.write("\n| 列名 | 类型 | 主键 | 非空 | 默认值 | 描述 |\n")
            md_file.write("|------|------|-----|-----|--------|-----|\n")
            for col in columns:
                md_file.write(
                    f"| `{col['name']}` | `{col['type']}` | "
                    f"{'✅' if col['pk'] else ''} | "
                    f"{'✅' if col['notnull'] else ''} | "
                    f"{'`'+str(col['dflt_value'])+'`' if col['dflt_value'] is not None else 'NULL'} | "
                    f" |\n"
                )

            # --- 索引信息 ---
            cursor.execute(f"PRAGMA index_list({table})")
            indexes = [dict(row) for row in cursor.fetchall()]

            if indexes:
                md_file.write("\n### 索引\n")
                for idx in indexes:
                    # 获取索引列
                    cursor.execute(f"PRAGMA index_info({idx['name']})")
                    idx_cols = [row['name'] for row in cursor.fetchall()]

                    md_file.write(
                        f"- **{idx['name']}** ({', '.join(idx_cols)})  "
                        f"{'UNIQUE' if idx['unique'] else ''}\n"
                    )

            # --- 外键信息 ---
            cursor.execute(f"PRAGMA foreign_key_list({table})")
            fks = [dict(row) for row in cursor.fetchall()]

            if fks:
                md_file.write("\n### 外键约束\n")
                md_file.write("| 名称 | 本表列 | 引用表 | 引用列 | 更新规则 | 删除规则 |\n")
                md_file.write(
                    "|------|--------|--------|--------|----------|----------|\n")
                for fk in fks:
                    md_file.write(
                        f"| {fk['id']} | `{fk['from']}` | `{fk['table']}` | "
                        f"`{fk['to']}` | {fk['on_update']} | {fk['on_delete']} |\n"
                    )

            # --- 数据样例 ---
            cursor.execute(f"SELECT * FROM {table} LIMIT 5")
            rows = cursor.fetchall()

            md_file.write("\n### 数据样例\n")
            if rows:
                headers = rows[0].keys()
                md_file.write("| " + " | ".join(headers) + " |\n")
                md_file.write("|" + "|".join(["---"] * len(headers)) + "|\n")

                for row in rows:
                    md_file.write("| " + " | ".join(
                        str(x) if x is not None else "NULL" for x in row
                    ) + " |\n")

                # 显示总行数
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                total = cursor.fetchone()[0]
                md_file.write(f"\n显示 5/{total} 行\n")
            else:
                md_file.write("*(空表)*\n")

            # 添加分隔线
            md_file.write("\n---\n")


def export_to_markdown(db_path, output_file):
    """将数据库导出为Markdown格式"""
    conn = sqlite3.connect(db_path)
    with open(output_file, 'w', encoding='utf-8') as md_file:
        
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row['name'] for row in cursor.fetchall()]
        
        for table in tables:
            md_file.write(f"## 表 `{table}`\n\n")
            
            # 表结构
            cursor.execute(f"PRAGMA table_info({table})")
            columns = [dict(col) for col in cursor.fetchall()]
            
            md_file.write("### 列结构\n")
            md_file.write("| 列名 | 类型 | 是否主键 |\n")
            md_file.write("|------|------|----------|\n")
            for col in columns:
                pk = "✅" if col['pk'] else ""
                md_file.write(f"| {col['name']} | {col['type']} | {pk} |\n")
            md_file.write("\n")
            
            # 数据
            cursor.execute(f"SELECT * FROM {table} LIMIT 100")
            rows = cursor.fetchall()
            
            if not rows:
                md_file.write("*(空表)*\n\n")
                continue
                
            md_file.write("### 数据样例\n")
            headers = rows[0].keys()
            md_file.write("| " + " | ".join(headers) + " |\n")
            md_file.write("|" + "|".join(["---"] * len(headers)) + "|\n")
            
            for row in rows[:100]:  # 限制前100行
                md_file.write("| " + " | ".join(map(str, row)) + " |\n")
            md_file.write("\n")

# 使用示例

db_path = "../db/monitor_metrics.db"

# 使用示例: 获取解析性文档
export_full_schema_to_markdown(db_path, "../db/database_schema.md")
# 打印100行数据内容
# export_to_markdown(db_path, "database_docs.md")