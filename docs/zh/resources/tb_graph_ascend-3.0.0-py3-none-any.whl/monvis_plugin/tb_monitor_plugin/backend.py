# mon_vis_plugin.py

import json
import os
import re
from typing import Dict, List, Any, Tuple, Set, Optional, Union

import sqlite3
from pathlib import Path
from tensorboard.backend.event_processing import event_accumulator
from tensorboard.plugins import base_plugin
from werkzeug import wrappers, Response, exceptions


class DatabaseManager:
    """Handles all database operations for the plugin."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn = None
        self._initialize_db_connection()

    def _initialize_db_connection(self) -> None:
        """Initialize database connection."""
        try:
            self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self.conn.row_factory = sqlite3.Row
        except sqlite3.Error as e:
            print(f"Error connecting to database: {e}")
            self.conn = None

    def is_connected(self) -> bool:
        """Check if database is connected."""
        return self.conn is not None

    def get_metrics_stat(self) -> List[str]:
        """Get all available metrics from database."""
        query = """
            SELECT m.metric_name, GROUP_CONCAT(ms.stat_name) as stats
            FROM monitoring_metrics m
            LEFT JOIN metric_stats ms ON m.metric_id = ms.metric_id
            GROUP BY m.metric_id
        """
        cursor = self.conn.execute(query)
        metrics = []
        for row in cursor.fetchall():
            metric_name = row['metric_name']
            stats = row['stats'].split(',') if row['stats'] else []
            metrics.append({
                "name": metric_name,
                "stats": stats
            })
        return metrics

    def get_metric_id(self, metric_name: str) -> Optional[int]:
        """Get metric ID for a given metric name."""
        query = "SELECT metric_id FROM monitoring_metrics WHERE metric_name = ?"
        cursor = self.conn.execute(query, (metric_name,))
        row = cursor.fetchone()
        return row['metric_id'] if row else None

    def get_global_stats(self) -> Dict[str, int]:
        """Get global statistics from database."""
        query = "SELECT stat_name, stat_value FROM global_stats"
        cursor = self.conn.execute(query)
        return {row['stat_name']: row['stat_value'] for row in cursor}

    def get_module_names(self) -> Dict[int, str]:
        """Get all module names with their target IDs."""
        query = "SELECT target_id, vpp_stage, target_name, micro_step FROM monitoring_targets"
        cursor = self.conn.execute(query)
        return {row["target_id"]: self._get_module_name(row) for row in cursor}

    def get_relevant_tables(self, metric_id: int) -> List[str]:
        """Get all tables relevant to a specific metric ID."""
        cursor = self.conn.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name LIKE 'metric_%_step_%'
        """)
        tables = [table['name'] for table in cursor]

        relevant_tables = []
        for table in tables:
            match = re.match(r'metric_(\d+)_step_(\d+)_(\d+)', table)
            if match and int(match.group(1)) == metric_id:
                relevant_tables.append(table)
        return relevant_tables

    def get_heatmap_data(self, table: str, stat: str, condition: str, params: tuple) -> List[Dict]:
        """Get data for heatmap visualization."""
        query = f"""
            SELECT t.rank, t.step, t.target_id, t.{stat}, m.target_name, m.vpp_stage, m.micro_step
            FROM {table} t
            JOIN monitoring_targets m ON t.target_id = m.target_id
            WHERE {condition}
        """
        cursor = self.conn.execute(query, params)
        return [dict(row) for row in cursor]

    def get_trend_data(self, table: str, stat: str, condition: str, params: tuple) -> List[Tuple]:
        """Get data for trend visualization."""
        query = f"""
            SELECT t.step, t.rank, t.target_id, t.{stat}, m.target_name, m.vpp_stage, m.micro_step
            FROM {table} t
            JOIN monitoring_targets m ON t.target_id = m.target_id
            WHERE {condition}
        """
        cursor = self.conn.execute(query, params)
        return [dict(row) for row in cursor]

    @staticmethod
    def _get_module_name(row: Dict) -> str:
        """Generate module name from row data."""
        return "_".join((
            str(row["target_id"]),
            str(row["vpp_stage"]),
            row["target_name"],
            str(row["micro_step"])
        ))


class ResponseBuilder:
    """Utility class for building consistent HTTP responses."""

    @staticmethod
    def success(data: Any) -> wrappers.Response:
        """Build a successful JSON response."""
        return wrappers.Response(
            json.dumps(data),
            content_type="application/json"
        )

    @staticmethod
    def error(message: str, status: int=500) -> wrappers.Response:
        """Build an error JSON response."""
        return wrappers.Response(
            json.dumps({"error": message}),
            content_type="application/json",
            status=status
        )

    @staticmethod
    def js_file(file_path: str) -> wrappers.Response:
        """Build a JavaScript file response."""
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        response = wrappers.Response(
            content,
            content_type="application/javascript"
        )
        response.headers['X-Content-Type-Options'] = 'nosniff'
        return response


class MonVis(base_plugin.TBPlugin):
    """MonVis TensorBoard Plugin for visualizing monitoring data."""

    plugin_name = "mon_vis"

    def __init__(self, context):
        super().__init__(context)
        self._log_dir = context.logdir
        self.db_path = os.path.join(self._log_dir, "monitor_metrics.db")
        self.js_file_path = os.path.join(
            os.path.dirname(__file__), "frontend", "index.js")
        self.echarts_file_path = os.path.join(
            os.path.dirname(__file__), "frontend", "echarts.js")
        self.db = DatabaseManager(self.db_path)

    def is_active(self) -> bool:
        """Determine if the plugin is active."""
        return self.db.is_connected()

    def frontend_metadata(self):
        """Return frontend metadata."""
        return base_plugin.FrontendMetadata(
            es_module_path="/index.js",
            tab_name="Mon_Vis"
        )

    def get_plugin_apps(self) -> Dict[str, Any]:
        """Return all HTTP routes for the plugin."""
        return {
            "/metrics": self._serve_metrics,
            "/values": self._serve_values,
            "/heatmap_data": self._serve_heatmap_data,
            "/trend": self._serve_trend_data,
            "/echarts.js": self._serve_echarts,
            '/index.js': self.static_file_route,
            '/index.html': self.static_file_route,
        
        }

    # ======================
    # Request Handlers
    # ======================
     # 静态文件路由
    @staticmethod
    @wrappers.Request.application
    def static_file_route(request):
        filename = os.path.basename(request.path)
        extension = os.path.splitext(filename)[1]
        if extension == '.html':
            mimetype = 'text/html'
        elif extension == '.js':
            mimetype = 'application/javascript'
        else:
            mimetype = 'application/octet-stream'
        current_dir = Path(__file__).resolve().parent
        server_dir = current_dir / "server"
        filepath = server_dir / "static" / filename
        print(filepath)
        try:
            with open(filepath, 'rb') as infile:
                contents = infile.read()
        except IOError as e:
            raise exceptions.NotFound('404 Not Found') from e
        return Response(contents, content_type=mimetype, headers={"X-Content-Type-Options": "nosniff"})

    @wrappers.Request.application
    def _serve_metrics(self, request) -> wrappers.Response:
        """Return all available metrics and fixed stats."""
        if not self.db.is_connected():
            return ResponseBuilder.error("Database connection failed")

        try:
            metrics = self.db.get_metrics_stat()
            return ResponseBuilder.success({
                "metrics": metrics,
            })
        except sqlite3.Error as e:
            return ResponseBuilder.error(f"Database error: {e}")

    @wrappers.Request.application
    def _serve_values(self, request) -> wrappers.Response:
        """Return list of values for specified metric, stat and dimension."""
        if not self.db.is_connected():
            return ResponseBuilder.error("Database connection failed")

        metric = request.args.get('metric')
        stat = request.args.get('stat')
        dimension = request.args.get('dimension')

        if not all([metric, stat, dimension in ['step', 'rank', 'module_name']]):
            return ResponseBuilder.error("Invalid parameters", 400)

        try:
            if dimension == "step":
                stats = self.db.get_global_stats()
                if "min_step" not in stats or "max_step" not in stats:
                    return ResponseBuilder.error("Step info not found in global_stats", 404)
                steps = range(stats["min_step"], stats["max_step"] + 1)
                values = {v: f"Step{v}" for v in steps}

            elif dimension == "rank":
                stats = self.db.get_global_stats()
                if "max_rank" not in stats:
                    return ResponseBuilder.error("Rank info not found in global_stats", 404)
                ranks = range(stats["max_rank"] + 1)
                values = {v: f"Rank{v}" for v in ranks}

            elif dimension == "module_name":
                values = self.db.get_module_names()

            return ResponseBuilder.success(values)
        except sqlite3.Error as e:
            return ResponseBuilder.error(f"Database error: {e}")

    @wrappers.Request.application
    def _serve_heatmap_data(self, request) -> wrappers.Response:
        """Return heatmap data for specified parameters."""
        if not self.db.is_connected():
            return ResponseBuilder.error("Database connection failed")

        metric = request.args.get('metric')
        stat = request.args.get('stat')
        dimension = request.args.get('dimension')
        value = request.args.get('value')

        if not all([metric, stat , dimension in ['step', 'rank', 'module_name'], value]):
            return ResponseBuilder.error("Invalid parameters", 400)

        try:
            metric_id = self.db.get_metric_id(metric)
            if not metric_id:
                return ResponseBuilder.error("Metric not found", 404)

            relevant_tables = self.db.get_relevant_tables(metric_id)
            if not relevant_tables:
                return ResponseBuilder.success({"data": []})

            selected_value = int(value)
            heatmap_data = []

            if dimension == "step":
                for table in relevant_tables:
                    rows = self.db.get_heatmap_data(
                        table, stat, "t.step = ?", (selected_value,)
                    )
                    heatmap_data.extend(
                        [row['rank'], (row['target_id'],
                                       self.db._get_module_name(row)), row[stat]]
                        for row in rows
                    )

            elif dimension == "rank":
                for table in relevant_tables:
                    rows = self.db.get_heatmap_data(
                        table, stat, "t.rank = ?", (selected_value,)
                    )
                    heatmap_data.extend(
                        [row['step'], (row['target_id'],
                                       self.db._get_module_name(row)), row[stat]]
                        for row in rows
                    )

            elif dimension == "module_name":
                for table in relevant_tables:
                    rows = self.db.get_heatmap_data(
                        table, stat, "m.target_id = ?", (selected_value,)
                    )
                    heatmap_data.extend(
                        [row['step'], (row['rank'], row['rank']), row[stat]]
                        for row in rows
                    )

            return ResponseBuilder.success({"data": heatmap_data})

        except sqlite3.Error as e:
            return ResponseBuilder.error(f"Database error: {e}")

    @wrappers.Request.application
    def _serve_trend_data(self, request) -> wrappers.Response:
        """Return trend data for specified parameters."""
        if not self.db.is_connected():
            return ResponseBuilder.error("Database connection failed")

        metric = request.args.get('metric')
        stat = request.args.get('stat')
        dimension = request.args.get('dimension')
        dim_x = request.args.get('dimX')
        dim_y = request.args.get('dimYIdx')

        if not all([metric, stat, dimension in ['step', 'rank', 'module_name'], dim_x, dim_y]):
            return ResponseBuilder.error("Invalid parameters", 400)

        try:
            metric_id = self.db.get_metric_id(metric)
            if not metric_id:
                return ResponseBuilder.error("Metric not found", 404)

            relevant_tables = self.db.get_relevant_tables(metric_id)
            if not relevant_tables:
                return ResponseBuilder.success({"data": []})

            dim_x = int(dim_x)
            dim_y = int(dim_y)
            trend_data = []
            if dimension == "step":
                for table in relevant_tables:
                    rows = self.db.get_trend_data(
                        table, stat, "t.rank = ? AND t.target_id = ?", (
                            dim_x, dim_y)
                    )
                    trend_data.extend((row['step'], row[stat]) for row in rows)
                dimensions, values = zip(
                    *sorted(trend_data, key=lambda x: x[0]))

            elif dimension == "rank":
                for table in relevant_tables:
                    rows = self.db.get_trend_data(
                        table, stat, "t.step = ? AND t.target_id = ?", (
                            dim_x, dim_y)
                    )
                    trend_data.extend((row['rank'], row[stat]) for row in rows)
                dimensions, values = zip(
                    *sorted(trend_data, key=lambda x: x[0]))

            elif dimension == "module_name":
                for table in relevant_tables:
                    rows = self.db.get_trend_data(
                        table, stat, "t.step = ? AND t.rank = ?", (
                            dim_x, dim_y)
                    )
                    trend_data.extend(
                        (row['target_id'], self.db._get_module_name(row), row[stat])
                        for row in rows
                    )
                dimensions, values = list(zip(
                    *sorted(trend_data, key=lambda x: x[0])))[1:]

            return ResponseBuilder.success({
                "data": {
                    "dimensions": dimensions,
                    "values": values
                }
            })

        except sqlite3.Error as e:
            return ResponseBuilder.error(f"Database error: {e}")

    @wrappers.Request.application
    def _serve_js(self, request) -> wrappers.Response:
        """Serve the JavaScript file."""
        return ResponseBuilder.js_file(self.js_file_path)

    @wrappers.Request.application
    def _serve_echarts(self, request) -> wrappers.Response:
        """Serve the ECharts JavaScript file."""
        return ResponseBuilder.js_file(self.echarts_file_path)
